TACO SHOP ASSEMBLY SPRITES

52 sequences and 304 individual transparent 45 x 46 PNG frames.
Source menu: https://tacoshop.net/menu/

frames-45x46/: Individual frames, numbered in order. Each frame shows the entire dish at that step.
sprite-strips/: One horizontal strip per sequence. Every frame is 45 pixels wide and 46 pixels tall, with no gaps.
previews/: Category previews enlarged with nearest-neighbor scaling.
assembly-steps.csv: Frame-by-frame ingredient and action list.
manifest.json: Sequence IDs, frame counts, image paths and steps for game import.
menu-coverage.csv: Menu entries, shared assemblies and items outside scope.
prompts.txt: Final built-in image generation prompts.

Recipes are based on the Taco Shop menu. Where the menu lists ingredients without a method, step order is an interpretation for the game. Ground beef stands in for menu descriptions that say seasoned meat; mild taco sauce stands in for the house sauce. Prepared Mexicalli rice and chili are approved components as supplied.

Giant tacos use larger artwork on the same 45 x 46 canvas. Portions and pack sizes reuse component sequences. The menu index records combos, single-component items, and recipes that require unapproved ingredients.

Corn shells start with a golden-yellow interior, shaded slightly darker than the rim. Use nearest-neighbor scaling to keep sprite edges crisp.
