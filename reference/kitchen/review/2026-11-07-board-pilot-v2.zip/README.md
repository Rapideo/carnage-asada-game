# Prep-board sprite pilot

The transparent 40×38 PNGs in `states/` show the whole dish after each ingredient pick. `manifest.json` maps the authored recipe prefixes to the PNG names and gives each dish its finished state.

| Preview row | Dish | Visible stages from left to right |
| --- | --- | --- |
| 1 | Hard Taco Supreme | Side-on corn shell, beef, lettuce, cheddar, green onions, tomato, sour cream |
| 2 | Bean Burrito | Large tortilla, refried beans, cheddar, closed roll |
| 3 | Nachos | Corn chips, glossy chili con queso, sliced jalapeños |
| 4 | Hard Taco | The first four sprites in row 1 |

Hard Taco, Hard Taco Supreme, and Nachos reuse their last ingredient sprite for the finished state. Bean Burrito uses a separate rolled sprite. The board is empty before the first pick.

`board-proof-native.png` shows each cutout in a 64×42 wood board cell at 1×. `board-proof-x4.png` magnifies the same layout with an approximation of scanlines. Both proofs use the project's 16-color palette reducer. The PNGs in `states/` retain the native-size source colors for the dev team's in-game test.

`source-sheets/` contains the three image-generated contact sheets and their prompts. The sprite files were cut, aligned, and reduced to the common canvas from those sources.

## Revision 2

The comparison rows are original taco, revised taco, original Nachos, revised Nachos. contrast-check.json records each step's changed pixel count at one fixed RGB threshold. The approved burrito uses its original art and prompt. The taco and Nachos sources use the prompts in revision-prompts.txt.

